package review2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Review2 {
    
    public static void main(String[] args) {
	//Create the scanner object (don't forget the import)
	Scanner keyboard = new Scanner(System.in);
	
	//Set up an empty list of items to be populated
	List<Item> items = new ArrayList<Item>();
	
	//Loop until the item name's length is <= 0 (blank)
	String name;
	do {
	    //Retrieve an item name
	    System.out.print("Item name? ");
	    name = keyboard.nextLine();
	    
	    if(name.length() > 0) {
		//Retrieve an item price
		System.out.print("Item price? ");
		double price = keyboard.nextDouble();
		keyboard.nextLine();
		
		//Retrieve an item quantity
		System.out.print("Item quantity? ");
		int quantity = keyboard.nextInt();
		keyboard.nextLine();

		//Add this new item to the list
		items.add(new Item(name, price, quantity));
	    }
	    
	    System.out.println();
	    
	} while(name.length() > 0);
	
	//Print off the items and calculate profit
	double profit = 0;
	for(Item item : items) {
	    System.out.println(item);
	    
	    profit += item.price * item.quantity;
	}
	
	//Print off the total profit and average profit
	System.out.println("Total profit: " + profit);
	System.out.println("Average profit: " + (profit / items.size()));
    }

}
