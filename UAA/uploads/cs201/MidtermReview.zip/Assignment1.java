package review;

import java.util.Random;
import java.util.Scanner;

public class Assignment1 {
    
    private static Scanner keyboard;
    
    public static void main() {
        keyboard = new Scanner(System.in);
        
        boolean playing = true;
        
        //Loop until the player decides not to play anymore
        while(playing) {
            String input;
            
            //Play each player's turn
            int p1 = turn(1);
            System.out.println();
            int p2 = turn(2);
            
            //Determine and declare the winners
            int winner = whoWon(p1, p2);
            if(winner > 0) {
                System.out.println("Player " + winner + " wins!");
            }
            else {
                System.out.println("No one won.");
            }
            
            //After the game ask to play again (this is the loop's exit condition)
            System.out.print("\nPlay again? ");
            input = keyboard.nextLine().toUpperCase();
            playing = input.startsWith("Y");
        }
        
        System.out.println("\nThanks for playing!");
    }
    
    public static int turn(int player) {
        String input;
        int hand = 0;
        
        //Loop until the player busts, hits 21 or decides to stay
        do {
            //Ask the player if they want to hit or stay
            System.out.printf("Player %d: %d\n", player, hand);
            System.out.print("Hit? ");
            input = keyboard.nextLine().toUpperCase();
        
            if(input.startsWith("N")) {
                //The player decided to stay
                return hand;
            }
            else if(input.startsWith("Y")) {
                //Deal a card to the player
                int newVal = hit();
                System.out.println("You get a " + newVal);
                hand += newVal;

                //Check for a player busting
                if(hand > 21) {
                    System.out.println("You busted!");
                    return hand;
                }
                else if(hand == 21) {
                    //Also return early if the player reaches 21
                    System.out.println("Blackjack!");
                    return hand;
                }
            }
            else {
                System.out.println("I don't understand.");
            }
             
        } while(true);        
    }
    
    public static int hit() {
        Random rnd = new Random();
        return rnd.nextInt(10) + 1;
    }
    
    public static int whoWon(int player1, int player2) {
        
        if(player1 == player2 || (player1 > 21 && player2 > 21)) {
            //Both have equal values or both busted
            return 0;
        }
        else if(player2 > 21 || (player1 <= 21 && player1 > player2)) {
            //Player 2 busted or player 1 won
            return 1;
        }
        else {
            //if(player1 > 21 || (player2 <= 21 && player2 > player1))
            //Player 1 busted or player 2 won
            //Note that this is not needed as it is the only remaining situation
            return 2;
        }
    }
    
}
