package review;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Assignment1WithClass {
    
    static Scanner keyboard;
    
    private Deck deck;
    private int[] player;

    public static void main() {
	keyboard = new Scanner(System.in);
        
        boolean playing = true;
        Assignment1WithClass game;
        String input;
        
        //Loop until the player decides not to play anymore
        while(playing) {
            //Create a new Blackjack object to hold the current game
            game = new Assignment1WithClass();
            game.play();
            
            //After the game ask to play again (this is the loop's exit condition)
            System.out.print("\nPlay again? [y/n] ");
            input = keyboard.nextLine().toUpperCase();
            playing = input.startsWith("Y");
        }
        
        System.out.println("\nThanks for playing!");
    }
    
    public void play() {
        //Shuffle the deck
        deck = new Deck();
        deck.shuffle();
        
        //Ask for the number of players and initialize their hands
        short playerCount = 0;
        do {
            System.out.println("How many players?");
            playerCount = keyboard.nextShort();
            
            keyboard.nextLine(); //Kill the buffer
        } while(playerCount < 1);
        
        player = new int[playerCount];
        
        //Play the turns for all players
        System.out.println();
        for(int playerNum = 0; playerNum < player.length; playerNum++) {
            player[playerNum] = turn(playerNum + 1);
            System.out.println();
        }
        
        //Loop again to list the final hand values
        System.out.println();
        for(int playerNum = 0; playerNum < player.length; playerNum++) {
            System.out.printf("Player %d: %d\n", playerNum + 1, player[playerNum]);
        }
        
        //Determine and declare the winners
        System.out.println();
        List<Integer> winners = whoWon(player);
        
        if(winners.isEmpty()) {
            System.out.println("No one won.");
        }
        else {
            String winnerList = "Player ";
            
            for(int winner : winners) {
                winnerList += (winner + 1) + ", ";
            }
            
            //Kill the last comma for the list of players
            winnerList = winnerList.substring(0, winnerList.length() - 2);
            
            System.out.println(winnerList + " wins!");
        }
    }
    
    public int turn(int player) {
        String input;
        int hand = 0;
        
        //Loop until the player busts, hits 21 or decides to stay
        do {
            //Ask the player if they want to hit or stay
            System.out.printf("Player %d: %d\n", player, hand);
            System.out.print("Hit? [y/n] ");
            input = keyboard.nextLine().toUpperCase();
        
            if(input.startsWith("N")) {
                //The player decided to stay
                return hand;
            }
            else if(input.startsWith("Y")) {
                //A hit was requested. Deal a card from the deck
                Card card = deck.deal();
                System.out.println("You get a " + card);
                
                //Then add it to the hand. The Card class deals with Aces
                hand += card.getValue();

                //Check for a player busting
                if(hand > 21) {
                    System.out.println("You busted!");
                    return hand;
                }
                else if(hand == 21) {
                    //Also return early if the player reaches 21
                    System.out.println("Blackjack!");
                    return hand;
                }
            }
            else {
                System.out.println("Could you repeat that?");
            }
             
        } while(true);        
    }
    
    public List<Integer> whoWon(int[] players) {
        //Slightly alternate rules due to the number of players
        //All players with the highest non-bust value win
        int highest = 0;
        ArrayList<Integer> winners = new ArrayList<Integer>();
        
        //Find the highest value
        for(int hand : players) {
            if(hand > highest && hand <= 21) {
                highest = hand;
            }
        }
        
        //Now find all players with that value
        //Note the for loop to remember the index of the current player
        for(int i = 0; i < players.length; i++) {
            if(players[i] == highest) {
                winners.add(i);
            }
        }
        
        return winners;
    }
    
}
