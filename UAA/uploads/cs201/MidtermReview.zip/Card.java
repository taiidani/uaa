package review;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class Card {
    
    private static String[] suits = { "Spades", "Clubs", "Hearts", "Diamonds" };
    
    private static HashMap<String, Integer> values = new HashMap<String, Integer>();
    
    private String suit;
    private String value;
    
    public Card(String suit, String value) {
        //Assigns what this card is going to be
        this.suit = suit;
        this.value = value;
    }
    
    public String getSuit() {
        //An accessor (getter) for the private suit variable
        return suit;
    }
    
    /**
     * An accessor (getter) for the private value variable
     * @return The name of this card
     */
    public String getName() {
        return value;
    }
    
    /**
     * An accessor (getter) for the private value variable's hand value
     * @return The hand value of this card
     */
    public int getValue() {
        //Set the actual hand value
        int realValue = values.get(value);

        if(realValue == 0) {
            //If the value is an Ace, ask the player how they want to deal with it
            Scanner input = new Scanner(System.in);

            //Loop until the player chooses a 1 or 11 for the ace
            while(realValue != 1 && realValue != 11) {
                System.out.print("You are holding an Ace. Should it be worth 1 or 11? ");
                realValue = input.nextInt();
            }

            //Clear the buffer of any remaining newline characters
            input.nextLine();
        } 

        //Return the temporary variable which has now been set properly
        return realValue;
    }
    
    @Override
    public String toString() {
        //The toString method determines how this object will look when printed
        return value + " of " + suit;
    }
    
    public static String[] getPossibleSuits() {
        return suits;
    }
        
    public static Set<String> getPossibleNames() {
        //Populate the possible values if they haven't yet been filled
        if(values.isEmpty()) {
            values.put("Ace", 0);
            values.put("One", 1);
            values.put("Two", 2);
            values.put("Three", 3);
            values.put("Four", 4);
            values.put("Five", 5);
            values.put("Six", 6);
            values.put("Seven", 7);
            values.put("Eight", 8);
            values.put("Nine", 9);
            values.put("Ten", 10);
            values.put("Jack", 10);
            values.put("Queen", 10);
            values.put("King", 10);
        }

        return values.keySet();
    }
}
