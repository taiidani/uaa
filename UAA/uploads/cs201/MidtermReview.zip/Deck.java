package review;

import java.util.ArrayList;
import java.util.Random;

public class Deck {
    
    private ArrayList<Card> cards;
    
    public void shuffle() {
        //Create an empty set of cards
        cards = new ArrayList<Card>();
        
        //Then populate the set. One card PER suit PER value
        for(String suit : Card.getPossibleSuits()) {
            for(String name : Card.getPossibleNames()) {
                //Create the card and set it's value to the current loop condition
                Card newCard = new Card(suit, name);
                
                //Then add it to the deck's cards variable
                cards.add(newCard);
            }
        }
    }
    
    public Card deal() {
        //Pull a random card from the deck and remove it (remove() will return what was taken)
        Random rnd = new Random();
        return cards.remove(rnd.nextInt(cards.size()));
    }
    
}
