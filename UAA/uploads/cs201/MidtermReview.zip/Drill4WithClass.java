package review;

public class Drill4WithClass {
    
    public static void main() {
        //An object to hold the counter. This can be thrown away or reset at will
        Counter cnt = new Counter();
        
        cnt.reset();
 
        cnt.increment(5);
        cnt.decrement(3);

        //Displays 2 (note the implicit use of the toString() method)
        System.out.println("The current amount is " + cnt);

        cnt.increment(4);

        //Displays 6
        System.out.println("The amount has been increased to " + cnt);

        cnt.reset();

        //Displays 0
        System.out.println("After resetting, the value has become " + cnt);
    }
    
    
    static class Counter {
        private int count = 0;
        
        /**
        * Resets the private count variable back to zero, forgetting
        * all of the counting done so far.
        */
       public void reset() {
           count = 0;
       }


       /**
        * Increases the count by the specified amount
        *
        * @param amount How much to increase the count by
        */
       public void increment(int amount) {
           count += amount;
       }

       /**
        * Decreases the count by the specified amount
        *
        * @param amount How much to decrease the count by
        */
       public void decrement(int amount) {
           count -= amount;
       }
       
       
       /**
        * Returns the string representation of the current counter value
        * @return The current count
        */
       public String toString() {
           return String.valueOf(count);
       }
    }
}
