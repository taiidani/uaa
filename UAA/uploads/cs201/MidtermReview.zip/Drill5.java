package review;

public class Drill5 {
    
    public static void main() {
        //Create an array to hold the 5 games
        String[] games = new String[5];
    
        //Note the index starting at 0 and going to 4
        games[0] = "Super Mario Galaxy";
        games[1] = "The Legend of Zelda: Ocarina of Time";
        games[2] = "Super Mario Galaxy 2";
        games[3] = "Grand Theft Auto IV";
        games[4] = "Soul Caliber";
        
        //Create an array to hold the 5 ratings
        double[] ratings = { 97.64, 97.54, 97.30, 97.05, 96.94 };

        System.out.println("The current all-time best games are:");
        
        //Loop through the games index. Each index will be at the same
        //position as the associated rating
        for(int i = 0; i < games.length; i++) {
            System.out.printf("\t%s at %.2f%%\n", games[i], ratings[i]);
        }
    }
}
