package review;

import java.util.HashMap;
import java.util.Map.Entry;

public class Drill5WithMap {
    
    public static void main() {
        //Create a HashMap (Dictionary) to map games to their ratings
        HashMap<String, Double> ratings = new HashMap<String, Double>();
        
        //The benefit to using a HashMap, each game's association is explicity shown
        ratings.put("Super Mario Galaxy", 97.64);
        ratings.put("The Legend of Zelda: Ocarina of Time", 97.54);
        ratings.put("Super Mario Galaxy 2", 97.30);
        ratings.put("Grand Theft Auto IV", 97.05);
        ratings.put("Soul Caliber", 96.94);
        
        System.out.println("The current all-time best games are:");
        
        //The negative, values are added out of order. This will print the
        //correct games, but in the wrong order
        for(Entry<String, Double> item : ratings.entrySet()) {
            System.out.printf("\t%s at %.2f%%\n", item.getKey(), item.getValue());
        }
    }
    
    
    
    
    
    
    
    
}
