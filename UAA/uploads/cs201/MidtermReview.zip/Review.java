package review;

public class Review {

    public static void main(String[] args) {
        
        //Variables, arithmetic operation, printing
        Drill1.main();
        System.out.println();
        
        //User input with Scanner, formatted output
        Drill2.main();
        System.out.println();
        
        //Conditionals, branching, comparing objects with .equals()
        Drill3.main();
        System.out.println();
        
        //Using static methods, passing and returning parameters
        Drill4.main();
        System.out.println();
        
        //Class-based use of methods, working with objects
        Drill4WithClass.main();
        System.out.println();
        
        //Arrays, for loop example
        Drill5.main();
        System.out.println();
        
        //HashMap, for-each looping example
        Drill5WithMap.main();
        System.out.println();
        
        //Assignment 1 solution
        Assignment1.main();
        System.out.println();
        
        //Assignment 1 extended solution
        Assignment1WithClass.main();
    }
}
