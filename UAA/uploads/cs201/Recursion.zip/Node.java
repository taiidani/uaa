package recursion;

public class Node {
    
    private int value;
    private Node left;
    private Node right;
    
    public Node(int value) {
	this.value = value;
    }

    public int getValue() {
	return value;
    }

    public Node getLeft() {
	return left;
    }

    public Node getRight() {
	return right;
    }

    public void addBranch(int left, int right) {
	addBranch(new Node(left), new Node(right));
    }
    
    public void addBranch(Node left, int right) {
	addBranch(left, new Node(right));
    }
    
    public void addBranch(int left, Node right) {
	addBranch(new Node(left), right);
    }
    
    public void addBranch(Node left, Node right) {
	this.left = left;
	this.right = right;
    }
    
    public String toString() {
	return getValue() + "";
    }
}
