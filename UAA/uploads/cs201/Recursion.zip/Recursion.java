package recursion;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class Recursion {
    
    static List<Integer> numbers;
    
    public static void main(String[] args) {
	
	for(int cnt = 0; cnt < 20; cnt++) {
	    System.out.print(fibonacci(cnt) + " ");
	}
		
	System.out.println();
	System.out.println();
	
	iterativeTree();
	
	System.out.println();
	
	recursiveTree();
    }
    
    
    public static int fibonacci(int times) {

	//RULE: fib(0) = 0
	if(times == 0) return 0;

	//RULE: fib(1) = 1
	else if(times == 1) return 1;

	//RULE: fib(n) = fib(n -1) + fib(n - 2)
	else return fibonacci(times - 1) + fibonacci(times - 2);
    }
    
    public static Node getStartingNode() {
	Node ret = new Node(0);
	ret.addBranch(1, 2);
	ret.getRight().addBranch(4, 5);
	ret.getLeft().addBranch(3, ret.getRight().getLeft());
	
	return ret;
    }
    
    public static void iterativeTree() {
	Stack<Node> nodes = new Stack<Node>();
	numbers = new ArrayList<Integer>();

	Node point = getStartingNode(); //Where startingNode is the bottom of the tree

	while(nodes.size() > 0 || point != null) {
	    if(point != null) {
		if(point.getValue() % 2 == 0 && !numbers.contains(point.getValue())) {
		    numbers.add(point.getValue());
		}

		//Add right node to the end of the stack for visiting later
		nodes.push(point.getRight());

		//Head down the left node
		point = point.getLeft();
	    }
	    else {
		//Hit the end of the tree; use the stack to process the next node
		point = nodes.pop();
	    }
	}

	for(Integer i : numbers) {
	    System.out.println(i + " ");
	}
	
    }
    
    public static void recursiveTree() {
	numbers = new ArrayList<Integer>();

	traverse(getStartingNode());

	for(Integer i : numbers) {
	    System.out.println(i);
	}
    }

    public static void traverse(Node point) {
	if(point == null) return;

	if(point.getValue() % 2 == 0 && !numbers.contains(point.getValue())) {
	    numbers.add(point.getValue());
	}

	traverse(point.getLeft());
	traverse(point.getRight());
    }

}
