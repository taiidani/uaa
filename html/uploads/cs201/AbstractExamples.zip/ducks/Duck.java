package ducks;

public abstract class Duck implements Duckable {
    
    public int wings = 2;

}
