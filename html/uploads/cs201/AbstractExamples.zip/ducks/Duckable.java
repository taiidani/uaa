package ducks;

public interface Duckable {
    
    void walk();
    void talk();
    
}
