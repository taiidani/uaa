package ducks;

import java.util.ArrayList;
import java.util.List;

public class Ducks {
    
    public static void main(String[] args) {
        
        List<Duckable> ducks = new ArrayList<Duckable>();
        ducks.add(new Goose());
        ducks.add(new Swan());
        ducks.add(new RonaldReagan());
        
        for(Duckable d : ducks) {
            System.out.println(d);
            d.walk();
            d.talk();
            System.out.println();
        }
    }

}
