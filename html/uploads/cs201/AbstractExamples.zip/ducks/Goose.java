package ducks;

public class Goose extends Duck {
    
    
    public Goose() {
        
    }
    
    public void walk() {
        System.out.println("Hop.");
    }
    
    public void talk() {
        System.out.println("Bray");
    }

}
