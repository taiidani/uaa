package ducks;

public abstract class Leader {

}
