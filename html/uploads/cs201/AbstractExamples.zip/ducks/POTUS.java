package ducks;

public class POTUS extends Leader {

}
