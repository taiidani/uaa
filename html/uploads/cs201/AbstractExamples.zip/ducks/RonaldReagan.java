package ducks;

public class RonaldReagan extends POTUS implements Duckable {
    
    
    public void walk() {
        System.out.println("Shuffle unhappily.");
    }
    
    public void talk() {
        System.out.println("Not much.");
    }

}
