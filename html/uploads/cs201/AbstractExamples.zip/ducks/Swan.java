package ducks;

public class Swan extends Duck implements Duckable {
    
    
    public Swan() {
        
    }
    
    public void walk() {
        System.out.println("No thanks");
    }
    
    public void talk() {
        System.out.println("Nuh uh.");
    }

}
