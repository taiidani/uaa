package exceptions;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;

public class Exceptions {

    public static void main(String[] args) {
        
        String name;
        String quest;
        String velocity;
        
        List<Askable> questions = new ArrayList<Askable>();
        questions.add(new NameQuestion());
        questions.add(new QuestQuestion());
        questions.add(new SwallowQuestion());
        
        try {
            do {
                try {
                    for(Askable q : questions) {
                        q.ask();
                    }
                    
                    System.out.println("You may pass!");
                    break;
                }
                catch(InputMismatchException ex) {
                    System.out.println("Eh?");
                }

            } while(true);
            
            
        }
        catch(IllegalArgumentException ex) {
            System.out.println("Wait, you confuse me, I don't know... AAARGH!");
            System.exit(1);
        }
    }
}
