package exceptions;

import java.util.InputMismatchException;

public class NameQuestion extends Question {
    
    public NameQuestion() {
        super("What is your name?");
    }
    
    
    public void validate(String answer) throws InputMismatchException, IllegalArgumentException {
        if(!answer.toLowerCase().startsWith("sir")) throw new InputMismatchException();
    }

}
