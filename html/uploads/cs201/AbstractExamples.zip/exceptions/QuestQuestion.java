package exceptions;

import java.util.InputMismatchException;

public class QuestQuestion extends Question  {
    
    public QuestQuestion() {
        super("What is your quest?");
    }
    
    public void validate(String answer) throws InputMismatchException, IllegalArgumentException {
        if(!answer.toLowerCase().contains("grail")) throw new InputMismatchException();
    }

}
