package exceptions;

import java.util.InputMismatchException;
import java.util.Scanner;

public abstract class Question implements Askable {
    
    protected String question;
    
    public Question(String q) {
        question = q;
    }

    public void ask() {
        Scanner keyboard = new Scanner(System.in);
        
        System.out.print(question);

        String ans = keyboard.nextLine();
        validate(ans);
    }
    
    
    public abstract void validate(String answer) throws InputMismatchException, IllegalArgumentException;
}
