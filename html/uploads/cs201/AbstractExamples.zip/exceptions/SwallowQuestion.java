package exceptions;

import java.util.InputMismatchException;

public class SwallowQuestion extends Question {
    
    
    public SwallowQuestion() {
        super("What is the air-speed velocity of an unladen swallow? ");
    }
    
    
    public void validate(String answer) throws InputMismatchException, IllegalArgumentException {
        if(answer.endsWith("?")) throw new IllegalArgumentException();
    }


}
