package inheritance;

public class Hawk extends Avian {

    public Avian layEgg() {
        Avian egg = super.layEgg();
        
        return (Hawk)egg;
    }
}
