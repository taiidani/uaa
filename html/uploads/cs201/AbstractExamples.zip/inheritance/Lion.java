package inheritance;

public class Lion extends Feline {
    
    
    public Lion() {
        super();
    }
    
    public Lion(String name) {
        super(name);
    }
    

}
