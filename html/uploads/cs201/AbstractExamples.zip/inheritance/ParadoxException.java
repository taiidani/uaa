package inheritance;

public class ParadoxException extends Exception {

    public ParadoxException() {
        this("A paradox occurred");
    }
    
    
    public ParadoxException(String message) {
        super(message);
    }
}
