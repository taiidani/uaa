package inheritance;

public class Penguin extends FlightlessAvian {

}
