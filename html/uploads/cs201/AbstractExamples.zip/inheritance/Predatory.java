/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author rnixon
 */
public interface Predatory {
    
    void attack(Predatory victim);
    
}
