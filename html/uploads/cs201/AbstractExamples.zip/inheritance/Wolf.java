package inheritance;

public class Wolf extends Canine {

}
