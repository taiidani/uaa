package review2;

public class Account {

    private static double funds = 20.00;
    
    /**
     * Withdraws the requested amount from the account. Throws a
     * FundsException if there is not enough money.
     */
    public static double withdrawFunds(double amount) throws FundsException {
	if(funds < amount) throw new FundsException();
	
	funds -= amount;
	
	return amount;
    }
    
    /**
     * Overloads withdrawFunds, allowing items to be passed in directly.
     */
    public static double withdrawFunds(Item item) throws FundsException {
	return withdrawFunds(item.getPrice());
    }
}
