package review2;

public class FundsException extends Exception {
    
    public FundsException() {
	super();
    }

}
