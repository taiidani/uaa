package maze;

public class Maze {
    
    
    public static void main(String[] args) {
	MazeFork startingPoint = generateMaze();
		
	//The correct path, no looping or recursion involved
	try {
	    MazeFork nextPoint = startingPoint.getLeft(); //Turn left (8 steps)
	    nextPoint = nextPoint.getLeft(); //Turn left (2 steps)
	    nextPoint = nextPoint.getRight(); //Turn right (8 steps)
	    nextPoint = nextPoint.getLeft(); //Turn left (6 steps)
	    nextPoint = nextPoint.getRight(); //Turn right (22 steps)
	    nextPoint = nextPoint.getRight(); //Turn right (33 steps)

	    //Now nextPoint is at the end
	    if(nextPoint.isEnd()) {
		System.out.println("You solved the maze!");
	    }
	    else {
		System.out.println("That's not the correct path.");
	    }
	}
	catch(NullPointerException e) {
	    System.out.println("You can't walk through walls!");
	}
    }
    
    /**
     * Generates a collection of MazeFork objects set up as a binary search tree.
     * Returns the root node of the tree.
     * @return The starting location of the maze
     */
    public static MazeFork generateMaze() {
	MazeFork startPoint = new MazeFork(4);
	startPoint.addBranch(8, 8);
	
	MazeFork traveler = startPoint.getRight();
	traveler.addBranch(10, 2);
	traveler = traveler.getLeft();
	traveler.addBranch(18, 12);
	
	traveler = startPoint.getLeft();
	traveler.addBranch(2, 8);
	traveler = traveler.getLeft();
	traveler.addBranch(8, 8);
	
	traveler = traveler.getRight();
	traveler.addBranch(6, 2);
	traveler = traveler.getLeft();
	traveler.addBranch(4, 22);
	
	traveler = traveler.getRight();
	traveler.addBranch(8, 33);
	
	traveler = traveler.getRight();
	traveler.makeEnd();
	
	return startPoint;
    }
    
}