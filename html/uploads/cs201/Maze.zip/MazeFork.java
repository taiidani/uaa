package maze;

public class MazeFork {
    
    private int steps;
    private MazeFork left;
    private MazeFork right;
    private boolean isEnd;
    
    public MazeFork(int steps) {
	this.steps = steps;
    }

    public int getSteps() {
	return steps;
    }

    public MazeFork getLeft() {
	return left;
    }

    public MazeFork getRight() {
	return right;
    }

    public void addBranch(int left, int right) {
	this.left = new MazeFork(left);
	this.right = new MazeFork(right);
    }
    
    public boolean isEnd() {
	return isEnd;
    }
    
    public void makeEnd() {
	isEnd = true;
    }
}
