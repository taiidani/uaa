package inheritance;

public class Avian extends Animalia {
    
    protected boolean hasTalons = true;
    
    public Avian layEgg() {
        Avian egg = new Avian();
        egg.setAge(0);
        return egg;
    }
    
    public void fly() throws Exception {
        
    }
    
    public void attack(Animalia victim) {
        System.out.println("\t" + this + " attacks " + victim + " with Talons!");
        
        //Birds always win.
        kill(victim);
    }
    
    public void kill(Animalia victim) {
        victim.die();
    }
}
