package inheritance;

public class Canine extends PredatoryMammal {
    
    public Canine() {
        super(42);
    }

}
