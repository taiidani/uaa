package inheritance;

public class Cat extends Feline {

}
