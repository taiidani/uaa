package inheritance;

public class Feline extends PredatoryMammal {
    
    protected boolean clawsExtended;

    public Feline() {
        super(30);
        clawsExtended = false;
    }
    
    public Feline(String name) {
        super(30, name);
        clawsExtended = false;
    }
    
    public void clawsRetract() {
        clawsExtended = true;
    }
    
    public void clawsExtend() {
        clawsExtended = true;
    }
}
