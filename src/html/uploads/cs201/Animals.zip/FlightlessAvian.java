package inheritance;

public class FlightlessAvian extends Avian {

    public void fly() throws Exception {
        throw new Exception("This bird cannot fly.");
    }
}
