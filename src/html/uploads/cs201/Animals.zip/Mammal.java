package inheritance;

public class Mammal extends Animalia {
    
    public Mammal() {
        super();
    }
    
    public Mammal(String name) {
        super(name);
    }
    
    protected Mammal liveBirth() {
        return new Mammal();
    }

}
