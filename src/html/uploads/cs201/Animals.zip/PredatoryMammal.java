package inheritance;

public class PredatoryMammal extends Mammal {
    
    protected int teeth;
    protected boolean hasClaws = true;
    
    public PredatoryMammal(int numTeeth) {
        super();
        teeth = numTeeth;
    }
    
    public PredatoryMammal(int numTeeth, String name) {
        super(name);
        teeth = numTeeth;
    }
    
    public void attack(Animalia victim) {
        System.out.println("\t" + this + " attacks " + victim + " with Claws!");
        
        //TODO Determine a winner depending on the weapon used
    }
    
    public void kill(Animalia victim) {
        victim.die();
    }
    
    public boolean hasClaws() {
        return hasClaws;
    }

}
