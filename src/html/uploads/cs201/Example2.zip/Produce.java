package review2;

public class Produce extends Item {
    
    private double pounds;
    
    public Produce(String name, double pricePerPound, double pounds) {
	//Use super to take advantage of Item's constructor
	super(name, pricePerPound, 1);
	this.pounds = pounds;
    }
    
    /**
     * Overrides Item!
     */
    public double getPrice() {
	return price * pounds;
    }
    
    public double getPounds() {
	return pounds;
    }
    
    /**
     * Overrides Item!
     */
    public String toString() {
	return name + ": " + getPrice() + " for " + getPounds() + "lbs";
    }

}
