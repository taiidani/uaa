package review2;

import java.util.Scanner;

public class Review2 {
    
    private static Scanner keyboard;
    
    public static void main(String[] args) {
	//Create the scanner object (don't forget the import)
	keyboard = new Scanner(System.in);
	Item item;
	
	//Grab the item's name early since it's shared
	System.out.print("Item name? ");
	String name = keyboard.nextLine();
	
	//Ask for the type to determine what object to use
	System.out.print("Item type? [I/P] ");
	String type = keyboard.nextLine();
	
	//Check the type input
	if(type.equals("I")) {
	    //Build an item
	    item = getItem(name);
	}
	else if(type.equals("P")) {
	    //Build a produce (item subclass, polymorphism allows for it)
	    item = getProduce(name);
	}
	else return;
	
	//Print out the item's toString method, whether it's produce or Item
	System.out.println(item);
    }
    
    /**
     * Create a new Item object from the input.
     */
    public static Item getItem(String name) {
	System.out.print("Item price? ");
	double price = keyboard.nextDouble();
	keyboard.nextLine();
	
	System.out.print("Item quantity? ");
	int quantity = keyboard.nextInt();
	keyboard.nextLine();
	
	return new Item(name, price, quantity);
    }
    
    /**
     * Create a new Produce object from the input.
     */
    public static Produce getProduce(String name) {
	System.out.print("Item price per pound? ");
	double price = keyboard.nextDouble();
	keyboard.nextLine();
	
	System.out.print("Item weight? ");
	double weight = keyboard.nextDouble();
	keyboard.nextLine();
	
	return new Produce(name, price, weight);
    }

}
