package review2;

public class Review2 {
    
    public static void main(String[] args) {
	
	String[] products = getProducts();
	String[] sortedProducts = new String[products.length];
	
	for(int i = 0; i < sortedProducts.length; i++) {
	    //Use a shared method to find the lowest string in the array
	    int smallest = findLowest(products);
	    
	    //Add the lowest string, then null it so it won't be found again
	    sortedProducts[i] = products[smallest];
	    products[smallest] = null;
	}
	
	//Print!
	for(String product : sortedProducts) {
	    System.out.println(product);
	}
	
	System.out.println();
	
	//Print recursive!
	for(String product : sortProducts(getProducts())) {
	    System.out.println(product);
	}
    }
    
    private static String[] sortProducts(String[] products) {
	return sortProducts(products, 0);
    }
    
    private static String[] sortProducts(String[] products, int i) {
	
	//Exit condition, if we've reached the size of the product array
	if(i == products.length) return new String[products.length];
	else {
	    //Use a shared method to find the lowest string in the array
	    int smallest = findLowest(products);
	    
	    //Keep that string around, but null it in the origin array
	    String str = products[smallest];
	    products[smallest] = null;
	    
	    //Send the array onwards, minus the found lowest item
	    String[] ret = sortProducts(products, i + 1);
	    
	    //Upon return, add the lowest item to the array
	    ret[i] = str;
	    
	    return ret;
	}
    }
    
    private static int findLowest(String[] products) {
	//Set the smallest invalid so the first comparison always works
	int smallest = -1;
	    
	for(int p = 0; p < products.length; p++) {
	    //Skip empty array items (they've already been found)
	    if(products[p] == null) continue;
	    
	    //If no smallest has been found yet
	    else if(smallest == -1) smallest = p;
	    
	    //See if we have a new lowest item
	    else if(products[p].compareTo(products[smallest]) < 0) {
		//We do! Keep its index around
		smallest = p;
	    }
	}
	
	return smallest;
    }
    

    private static String[] getProducts() {
	String[] products = new String[5];
	products[0] = "Food Cube";
	products[1] = "Sandvich";
	products[2] = "Cotton Candy";
	products[3] = "Soylent Green";
	products[4] = "Donut";
	
	return products;
    }

}
